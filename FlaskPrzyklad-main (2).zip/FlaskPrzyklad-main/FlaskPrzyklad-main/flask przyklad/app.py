from flask import Flask, render_template, redirect, url_for, request, flash, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "tajny_klucz"  # Klucz do szyfrowania sesji (musisz zmienić na coś trudnego)

# Inicjalizacja managera logowania
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"  # Widok, na który użytkownik zostanie przekierowany, jeśli nie jest zalogowany

# Przykład użytkowników z hasłami zaszyfrowanymi
users = {
    "admin": {"password": generate_password_hash("1234"), "role": "admin"},
    "student": {"password": generate_password_hash("studentpass"), "role": "student"},
    "lecturer": {"password": generate_password_hash("lecturerpass"), "role": "lecturer"},
}

# Użytkownicy oczekujący na akceptację przez administratora
pending_users = {
    "student1": {"password": generate_password_hash("studentpass"), "role": "student"},
    "lecturer1": {"password": generate_password_hash("lecturerpass"), "role": "lecturer" }
}

# To jest klasa reprezentująca użytkownika
# Wymaga identyfikatora użytkownika i roli
class User(UserMixin):
    def __init__(self, id, role):
        self.id = id
        self.role = role

# Funkcja do ładowania użytkownika po ID
# To jest część logiki logowania
@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        role = users[user_id].get("role")
        return User(user_id, role)
    return None  # Jeśli użytkownik nie istnieje, zwraca None

# Dekorator sprawdzający rolę użytkownika
# Sprawdza, czy użytkownik ma odpowiednią rolę (np. admin, student)
def role_required(role):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if current_user.is_authenticated and current_user.role == role:
                return func(*args, **kwargs)
            else:
                abort(403)  # Brak dostępu, zwraca błąd 403
        return wrapper
    return decorator

@app.route('/')
def home():
    return render_template('home.html')  # Strona główna

@app.route('/about')
def about():
    return render_template('about.html')  # Strona 'o nas'

@app.route('/faq')
def faq():
    return render_template('faq.html')  # Strona FAQ

# Logika logowania
# Ta część obsługuje formularz logowania użytkowników
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":  # Sprawdzamy, czy formularz został wysłany
        username = request.form["username"]  # Pobieramy nazwę użytkownika
        password = request.form["password"]  # Pobieramy hasło użytkownika
        if username in users and check_password_hash(users[username]["password"], password):
            role = users[username]["role"]
            user = User(username, role)  # Tworzymy obiekt użytkownika
            login_user(user)  # Logujemy użytkownika
            flash("Zalogowano pomyślnie!", "success")  # Wyświetlamy komunikat o sukcesie
            return redirect(url_for("dashboard"))  # Przekierowujemy na stronę dashboardu
        else:
            flash("Nieprawidłowe dane logowania.", "danger")  # Komunikat o błędnych danych logowania
    return render_template("login.html")

# To jest logika akceptowania użytkowników przez administratora
@app.route("/admin/pending_users", methods=["GET", "POST"])
@login_required
@role_required("admin")
def admin_pending_users():
    if request.method == "POST":  # Sprawdzamy, czy formularz został wysłany
        action = request.form.get("action")  # Pobieramy akcję (zaakceptować lub odrzucić)
        username = request.form.get("username")  # Pobieramy nazwę użytkownika
        
        if action == "accept" and username in pending_users:
            users[username] = pending_users.pop(username)  # Akceptujemy użytkownika
            flash(f"Użytkownik {username} został zaakceptowany.", "success")
        elif action == "reject" and username in pending_users:
            pending_users.pop(username)  # Odrzucamy użytkownika
            flash(f"Użytkownik {username} został odrzucony.", "info")
    
    return render_template("admin_pending.html", pending_users=pending_users)

# Strona chroniona (dostępna tylko po zalogowaniu)
@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", role=current_user.role)  # Przekazujemy rolę użytkownika do dashboardu

# Logowanie użytkownika (wylogowanie)
@app.route("/logout")
@login_required
def logout():
    logout_user()  # Wylogowanie użytkownika
    flash("Wylogowano pomyślnie!", "success")  # Komunikat o sukcesie
    return redirect(url_for("login"))  # Przekierowanie na stronę logowania

# Rejestracja użytkownika
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":  # Sprawdzamy, czy formularz został wysłany
        username = request.form["username"]  # Pobieramy nazwę użytkownika
        password = request.form["password"]  # Pobieramy hasło użytkownika
        role = request.form.get("role", "student")  # Domyślnie nadajemy rolę "student"
        
        if username in users:
            flash("Użytkownik o podanej nazwie już istnieje.", "danger")
        elif not username or not password:
            flash("Nazwa użytkownika i hasło nie mogą być puste.", "danger")
        else:
            # Dodajemy użytkownika do słownika pending_users
            pending_users[username] = {"password": generate_password_hash(password), "role": role}
            flash("Rejestracja zakończona pomyślnie! Oczekujesz na zatwierdzenie przez administratora.", "success")
            return redirect(url_for("login"))  # Przekierowanie na stronę logowania
    
    return render_template("register.html")

# To jest panel administratora
# W tej sekcji admin może akceptować lub odrzucać użytkowników
@app.route("/admin")
@login_required
@role_required("admin")
def admin_panel():
    return render_template("admin_panel.html", pending_users=pending_users)

# Inne panele (dla studenta i wykładowcy)
@app.route("/student")
@login_required
@role_required("student")
def student_panel():
    return "Witaj w panelu studenta!"

@app.route("/lecturer")
@login_required
@role_required("lecturer")
def lecturer_panel():
    return "Witaj w panelu wykładowcy!"

if __name__ == "__main__":
    app.run(debug=True)  # Uruchomienie aplikacji
