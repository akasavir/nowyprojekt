# FlaskPrzyklad
Przyklad kodu we flask ktory pomoze nam zbudowac projekt na studia
